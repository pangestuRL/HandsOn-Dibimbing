let nama = `Doni`;
const alamat = `Bandung`;

Module.export = {
    nama,
    alamat,
};