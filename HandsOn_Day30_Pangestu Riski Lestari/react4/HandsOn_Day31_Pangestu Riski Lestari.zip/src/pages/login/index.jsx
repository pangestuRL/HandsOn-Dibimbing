import Navbar from "../../components/Navbar";

function Login(){

    return(
        <div>
            <Navbar/>
            <h1>ini adalah login page</h1>
        </div>
    )
}

export default Login;