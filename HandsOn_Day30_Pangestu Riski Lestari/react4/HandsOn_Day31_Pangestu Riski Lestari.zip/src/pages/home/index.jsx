import { useState, useEffect } from 'react'
import axios from 'axios'
import UserSection from '../../components/UserSection'
import Navbar from '../../components/Navbar'
// import Sidebar from './components/sidebar'


// function App(){
//   const [sidebar, setSidebar] = useState(false)

//   const menuNav = ['Home', 'About', 'Contact']
//   const handleNav = () => setSidebar(!sidebar)
  
//   return(
//     <>
//       {!sidebar && <p onClick={handleNav}>|||</p>}
//       {sidebar && <Sidebar menuNav = {menuNav} handleNav={handleNav}/>}
//     </>
//   )
// }

// const App = () => {

//   const [menu,setMenu] = useState([]) //ini kurung kurawal karena data dr API berupa banyak data yg harus di tampung. jd ini tergantung data yg ada di API

//   const getMenu = () => {
//     axios
//       .get("https://api.mudoapi.site/menus") //get disini adl protokol. jd bisa get, post, put/patch, delete
//       .then(res => { //then untuk kalau berhasil
//         const dataMenu = res.data.data.Data; //kenapa ada 3 .data? karena stuktur datanya. jd harus console log dulu
//         setMenu(dataMenu);
//       })
//       .catch(err =>{ //catch untuk yang gagal
//         console.log("ini data gagal", err);
//       })
//   };

//   //useEffect adalah Lifecycle hooks, untuk memanggil/ menjalankan function ketika pertama kali di render
//   useEffect(() => {
//     getMenu();
//   }, []); //array ini untuk parameter, kalau tdk ada yg dicek brarti array kosong

//   console.log('Menu', menu);

//   return (
//     <div>
//       <h1>Hello World</h1>
//       {menu.map(item => (
//         <div key={item.id}>
//           <h1>{item.name}</h1>
//           <p>{item.price}</p>
//           <img width={200} src={item.imageUrl} alt={item.name} />
//         </div>
//       ))}
//     </div>
//   );
// };

const Home = () => {
  const [user,setUser] = useState([])

  const getUser = () => {
        axios
          .get("https://reqres.in/api/users?page=2") //get disini adl protokol. jd bisa get, post, put/patch, delete
          .then(res => { //then untuk kalau berhasil
            const dataUser = res.data.data; //kenapa ada 3 .data? karena stuktur datanya. jd harus console log dulu
            setUser(dataUser);
            // console.log("ini data berhasil", res);
          })
          .catch(err =>{ //catch untuk yang gagal
            console.log("ini data gagal", err);
          })
      };

    useEffect(() => {
          getUser();
        }, []); //array ini untuk parameter, kalau tdk ada yg dicek brarti array kosong
      
        console.log('User', user);

  return (
    <div>
        <Navbar/>
       <h1>Hello World</h1>
       <UserSection user = {user}/>
    </div>
  )
}

export default Home;

//lifecycle atau siklus hidup aplikasi, ada 3:
//1. mounting = aplikasi pertama di buka
//2. update = ketika sesuatu berubah maka aplikasi mentriger
//3. unmount = ketika aplikasi di tutup/close

//1. panggil API
//2. simpan data dr api
//3. render data yang disimpan di dalam state berasal dari API