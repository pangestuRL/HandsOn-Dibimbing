import Navbar from "../../components/Navbar";

function MenuDetail (){

    return (
        <div>
            <Navbar/>
            <h1>ini menu detail page</h1>
        </div>
    )
}

export default MenuDetail;