import axios from "axios";
import { useState, useEffect } from "react";
import Navbar from "../../components/Navbar";

const Profile = () => {
    const [profile, setProfile] = useState({});

    const getProfile = async () => {
        const token = localStorage.getItem("accessToken");
        const config = {
        header : {
            Authorization: `Bearer ${token}`,
        }
        };

        try {
            const response = await axios.get("https://dummyjson.com/auth/me", config);
            setProfile(response.data);
            console.log("res", response);
        }
        catch (error){
            console.log("err", error.response);
        }
    };

    useEffect (() => {
        getProfile();
    }, []);
    

    
    
    return (
        <div>
            <Navbar/>
            <h1>Ini Profile Page</h1>
            <div>
                <p>{profile.username}</p>
                <img src={profile.img} alt="" />
                <p>{profile.gender}</p>
            </div>
        </div>
    )

}

export default Profile;