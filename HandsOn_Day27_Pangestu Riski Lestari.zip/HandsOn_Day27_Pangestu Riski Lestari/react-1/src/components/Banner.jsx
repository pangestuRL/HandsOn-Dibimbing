function Banner () {

    return(
        <div>
            <div>
                <img src="https://plus.unsplash.com/premium_photo-1667912925305-629794bdb691?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YmFubmVyfGVufDB8fDB8fHww" alt="image" />
                <img src="https://images.unsplash.com/photo-1513151233558-d860c5398176?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGJhbm5lcnxlbnwwfHwwfHx8MA%3D%3D" alt="image2" />
            </div>
        </div>
    )
}

export default Banner