function Navbar () {
    
    return (
        <div>
            <div>
                <h1>Logo</h1>
            </div>
            <div>
                <p>Menu</p>
                <p>About Us</p>
                <p>Contact</p>
            </div>
        </div>
    )


}

export default Navbar