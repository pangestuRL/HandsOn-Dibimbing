
let data = [ 6, 8, 10];
//           0  1   2

console.log(data[2]); // akan muncul 10 (index ke-2)
console.log(data.length); // jumlah datanya (3)

// loop angka => dari berapa, sampai berapa (range)

//    start       kondisi         increment
for (let i = 0; i < 3; i++) { // i = 3  
    // console.log(i);
}


for (let i = 0; i < data.length; i++) {
    console.log(data[i]);
    
}
