
for (let i = 0; i >= 0; i++) {
    
    console.log(i);

    if (i === 1000) { // kondisi untuk menghentikan loop
        break;
    }
    
}

console.log("loop sudah berhenti");
