let arr = [];

arr[0] = 1;
arr[0]++;

arr[3] = 8;

arr[7] = 100;

console.log(arr);
