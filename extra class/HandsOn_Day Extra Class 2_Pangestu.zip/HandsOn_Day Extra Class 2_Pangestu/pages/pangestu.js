export default function PangestuPages(){
    return <div>Pangestu Pages</div>
}