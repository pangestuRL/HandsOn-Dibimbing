(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages_user_[id]_ssr_5771e187.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages_user_[id]_ssr_5771e187.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_eb81a647._.js",
    "static/chunks/node_modules_react-dom_82bb97c6._.js",
    "static/chunks/node_modules_1b7400a8._.js",
    "static/chunks/[root of the server]__09702f65._.js"
  ],
  "source": "entry"
});
