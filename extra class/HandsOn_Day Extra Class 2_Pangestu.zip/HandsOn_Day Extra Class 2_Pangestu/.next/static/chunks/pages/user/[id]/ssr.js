__turbopack_load_page_chunks__("/user/[id]/ssr", [
  "static/chunks/node_modules_next_dist_eb81a647._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_1b7400a8._.js",
  "static/chunks/[root of the server]__09702f65._.js",
  "static/chunks/pages_user_[id]_ssr_5771e187.js",
  "static/chunks/pages_user_[id]_ssr_32401d26.js"
])
