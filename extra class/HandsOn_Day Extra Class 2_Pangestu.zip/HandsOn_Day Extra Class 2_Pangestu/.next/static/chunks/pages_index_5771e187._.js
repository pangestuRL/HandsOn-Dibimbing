(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages_index_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages_index_5771e187._.js",
  "chunks": [
    "static/chunks/node_modules_next_03d511eb._.js",
    "static/chunks/node_modules_react-dom_82bb97c6._.js",
    "static/chunks/node_modules_1b7400a8._.js",
    "static/chunks/[root of the server]__3759f8a9._.js"
  ],
  "source": "entry"
});
