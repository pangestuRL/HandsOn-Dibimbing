import { useRouter } from "next/router";
import axios from "axios";

export const getServerSideProps = async({query}) => {
    console.log("sampai sini")
    const resp = await axios.get(`https://api-bootcamp.do.dibimbing.id/api/v1/foods/${query.id}`, {
        headers: {
            apiKey: "w05KkI9AWhKxzvPFtXotUva-",
        }
    })
    console.log(resp);
    return {props:{
        food: resp.data,
    }}
}

const FoodDetail = ({food}) => {
    const router =useRouter();
    const id = router.query.id;

    const handleUpdate = async() => {
        await axios.post(`https://api-bootcamp.do.dibimbing.id/api/v1/update-food/${id}`, 
            {
                name: "Buaya Gepuk Sambal Tampar",
                description: "Ayam Geprek Terbaik",
                imageUrl: "https://img-global.cpcdn.com/recipes/4f29e3debf3bd281/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg",
                ingredients:["ayam", "sambal", "bawang"],
                price:50000
            },
            {
                headers:{
                    apiKey: "w05KkI9AWhKxzvPFtXotUva-",
                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im1pZnRhaGZhcmhhbkBnbWFpbC5jb20iLCJ1c2VySWQiOiJjYTIzZDdjYy02Njk1LTQzNGItODE2Yy03ZTlhNWMwNGMxNjQiLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE2NjE4NzUzMjF9.wV2OECzC25qNujtyb9YHyzYIbYEV-wud3TQsYv7oB4Q"
                }
            }
        )
        router.reload();
        alert("Berhasil di Ubah!")
    }

    const handleDelete = async () => {
        await axios.delete(`https://api-bootcamp.do.dibimbing.id/api/v1/delete-food/${id}`, 
            {
                headers:{
                    apiKey: "w05KkI9AWhKxzvPFtXotUva-",
                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im1pZnRhaGZhcmhhbkBnbWFpbC5jb20iLCJ1c2VySWQiOiJjYTIzZDdjYy02Njk1LTQzNGItODE2Yy03ZTlhNWMwNGMxNjQiLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE2NjE4NzUzMjF9.wV2OECzC25qNujtyb9YHyzYIbYEV-wud3TQsYv7oB4Q"
                }
            }
        );
        alert("Berhasil Dihapus!");
    }
    
    return <div className="">
        <img src={food.data.imageUrl}/>
        <h1>{food.data.name}</h1>
        <button onClick={handleUpdate} className="bg-green-800 p-2 rounded-lg text-white mr-3">Update</button>
        <button onClick={handleDelete} className="bg-red-600 p-2 rounded-lg text-white">Delete</button>
    </div>
}

export default FoodDetail;