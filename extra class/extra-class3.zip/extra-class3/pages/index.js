import axios from "axios";

export async function getServerSideProps() {
  const resp = await axios.get(`https://api-bootcamp.do.dibimbing.id/api/v1/foods`, {
    headers: {
      apiKey: "w05KkI9AWhKxzvPFtXotUva-",
    }
  })
  
  return {
    props:{
      initialFoods: resp.data,
    }
  }
};

const HomePage = ({ initialFoods }) => {
  return (
    <div className="mx-0.5">
      <h1 className="text-center font-bold text-4xl m-9">Daftar Makanan</h1>
      <ul className="grid grid-cols-4 justify-center gap-2">
        {initialFoods.data.map((food) => (
          <FoodCard key={food.id} food={food} />
        ))}
      </ul>
    </div>
  );
};

const FoodCard = ({ food }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-4 w-72 hover:bg-amber-100">
      <img className="w-full h-40 object-cover rounded-lg" src={food.imageUrl} alt={food.name} width="150" />
      <h3 className="text-lg font-semibold mt-3">{food.name}</h3>
      <p>{food.id}</p>
      <p className="text-gray-500 text-sm mt-1">{food.description}</p>
      <div className="mt-3 flex justify-between items-center">
        <span className="text-green-500 font-bold text-lg">${food.price}</span>
        <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition">
          Order
        </button>
      </div>
    </div>
  );
};

export default HomePage;