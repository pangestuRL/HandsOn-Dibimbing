__turbopack_load_page_chunks__("/food/[id]", [
  "static/chunks/node_modules_next_ce022631._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_1b7400a8._.js",
  "static/chunks/[root of the server]__c3387ee5._.js",
  "static/chunks/pages_food_[id]_5771e187.js",
  "static/chunks/pages_food_[id]_f9116852.js"
])
