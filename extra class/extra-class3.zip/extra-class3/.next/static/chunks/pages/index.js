__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_dist_eb81a647._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_1b7400a8._.js",
  "static/chunks/[root of the server]__3759f8a9._.js",
  "static/chunks/pages_index_5771e187._.js",
  "static/chunks/pages_index_5ca3310f._.js"
])
