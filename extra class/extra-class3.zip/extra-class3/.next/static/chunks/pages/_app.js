__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_eb81a647._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_1b7400a8._.js",
  "static/chunks/[root of the server]__c0067d82._.js",
  "static/chunks/styles_globals_79636149.css",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_54f1c2c5._.js"
])
