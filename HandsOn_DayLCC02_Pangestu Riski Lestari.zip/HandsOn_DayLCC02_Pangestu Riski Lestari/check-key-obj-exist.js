
let obj = {'1' : 0, '5' : 0, '1000' : 0}


let key = 10;
console.log( typeof obj[key] === 'undefined'); // 'undenifined

let key2 = 5;
console.log( typeof obj[key2] === 'undefined' ); // 'number'
